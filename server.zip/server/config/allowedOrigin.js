const allowedOrigin = [
    "http://localhost:3000",
    "https://6vzqkvwl-5501.usw3.devtunnels.ms/",
    "http://127.0.0.1:5502",
    "https://fathiabams-task.onrender.com",
    "https://127.0.0.1:5502/frontend/",
    "https://fathiabams-task.vercel.app",
    "https://www.profitsplus115.com.ng",
    "http://www.profitsplus115.com.ng",
    "https://www.theprofitplus.com.ng",
    "https://profits-plus-backend.onrender.com",
    "https://www.theprofitplus.com.ng",
    'https://www.theprofitplus.com.ng',
    'https://theprofitplus.com.ng'
];
module.exports = allowedOrigin;
