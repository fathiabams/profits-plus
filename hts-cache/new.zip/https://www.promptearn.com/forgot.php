<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="logo/prompt.png">
<title>Reset Your Password | The Best Platform for Earning Online With Digital Product</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;700&display=swap">
  
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  
<!-- Google tag (gtag.js) --> 


<script async src="https://www.googletagmanager.com/gtag/js?id=G-30Z5L83XBH"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-30Z5L83XBH');
</script>
</head>
<body class="layout-default">
    
    <style>
    
   
    #pyly{
        margin-bottom:0px; padding-bottom:0px; margin-top:0px;
    }
    @import url(//fonts.googleapis.com/css?family=Montserrat:300,400,500);
.service-11 {
  font-family: "Montserrat", sans-serif;
	color: #8d97ad;
  font-weight: 300;
}

.service-11 h1, .service-11 h2, .service-11 h3, .service-11 h4, .service-11 h5, .service-11 h6 {
  color: #3e4555;
}

.service-11 .font-weight-medium {
	font-weight: 500;
}

.service-11 .bg-light {
    background-color: #f4f8fa !important;
}

.service-11 .subtitle {
    color: #8d97ad;
    line-height: 24px;
}

.service-11 .card.card-shadow {
    -webkit-box-shadow: 0px 0px 30px rgba(115, 128, 157, 0.1);
    box-shadow: 0px 0px 30px rgba(115, 128, 157, 0.1);
}

.service-11 .wrap-service11-box {
  margin-top: 0px;
}

.service-11 .wrap-service11-box .icon-space {
  margin: -120px 0 20px;
}

.service-11 .wrap-service11-box .icon-space .icon-round {
  font-size: 45px;
  color: #ffffff;
}

.service-11 .bg-success-gradiant {
    background: #2cdd9b;
    background: -webkit-linear-gradient(legacy-direction(to right), #2cdd9b 0%, #1dc8cc 100%);
    background: -webkit-gradient(linear, left top, right top, from(#2cdd9b), to(#1dc8cc));
    background: -webkit-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: -o-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: linear-gradient(to right, #2cdd9b 0%, #1dc8cc 100%);
}

.service-11 .icon-round {
		width: 80px;
    line-height: 80px;
}

.service-11 .btn-success-gradiant {
		background: #2cdd9b;
    background: -webkit-linear-gradient(legacy-direction(to right), #2cdd9b 0%, #1dc8cc 100%);
    background: -webkit-gradient(linear, left top, right top, from(#2cdd9b), to(#1dc8cc));
    background: -webkit-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: -o-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: linear-gradient(to right, #2cdd9b 0%, #1dc8cc 100%);
}

.service-11 .btn-success-gradiant:hover {
		background: #1dc8cc;
    background: -webkit-linear-gradient(legacy-direction(to right), #1dc8cc 0%, #2cdd9b 100%);
    background: -webkit-gradient(linear, left top, right top, from(#1dc8cc), to(#2cdd9b));
    background: -webkit-linear-gradient(left, #1dc8cc 0%, #2cdd9b 100%);
    background: -o-linear-gradient(left, #1dc8cc 0%, #2cdd9b 100%);
    background: linear-gradient(to right, #1dc8cc 0%, #2cdd9b 100%);	
}

.service-11 .btn-md {
    padding: 15px 45px;
    font-size: 16px;
}
    #whatwe{
        margin-top:600px;
    }
    #joo{
        max-width:600px; 
        float:left; 
        margin-left:120px;
    }
    .btnhoo{
        background-color:#5dad00;  color:white; width:200px;
    }
    #massiv{
        font-weight:bold; font-size:60px; color:black; font-family:raleway;
    }

    #stata{
        margin-right:40px;
    }
    #footlin{
       float:left; margin-right:90px; 
    } 
    #footlin2{
       float:left; margin-right:0px; 
    }
    #footbox2{
        float:left; width:800px;
    } 
    #footbox3{
        float:right; max-width:750px;
    }
    #joo2{
        max-width:500px; float:left;
    }
    #semiblockhead{
        font-size:35px; font-family: raleway; font-weight:bold; color:#082515;
									line-height:50px; margin-top:30px; margin-left:50px;
    }
    #semiblockhead2{
        font-family: raleway; margin-top:30px; margin-left:50px;
    }
    #semiblockheadbtn{
        margin-left:50px; background-color:#5dad00;  color:white; width:200px;
    }
    #semiblockheadmargin{
        margin-top:200px;
    }
    
    #thirdblockimg1{
        display:none;
    }
    #thirdblockmargin{
        margin-top:200px;
    }
    #testimonialhead{
       text-align:center; max-width:700px; font-size:35px; font-family: raleway; font-weight:bold; color:black;
	   line-height:50px; margin:0px auto; float:none; 
    }
    #arrowtesti1{
        cursor:pointer; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:13px; float:right; height: 50px; width:50px;
        font-size:30px; color:white;                                        
    }
    #arrowtesti2{
        cursor:pointer; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:13px; float:right; height: 50px; width:50px;
        font-size:30px; color:white;
    }
    #testiarrobox{
       display:none;
    }
    #aftertesti{ 
        padding-bottom:0px; padding-top:200px; margin-bottom:0px; width:100%;
    }
    #faqquestion{
        font-family:raleway; font-weight:bold;
    }
    #faqbtn{
        background-color:white; text-align:left; white-space:normal; width:100%; box-shadow:none; color:black; text-decoration:none;
    }
    #lastone2{
        padding-top:60px; padding-left:60px;
    }
    #lastone3{
        padding-left:60px;
    }
    #btn11xx{
		margin-left:0px; float:left; background-color:#5dad00;  color:white; width:220px;
	}
	#btn22xx{
		padding-left:20px; float:left; margin-left:20px;  padding-right:20px; width:220px; background-color:transparent; border:1px solid #112111; color:#112111;
	}
	#headerab{
	    font-size:65px; font-family: raleway; font-weight:bold; color:black; text-align:center;
	}
	#visionb{
	    border-left:3px solid #5dad00; text-align:center;
	}
	#sbox22{
	    padding-top:110px; padding-left:90px; padding-right:90px;
	}
	#mlogo{
	    display:none;
	}
	
    @media screen and (max-width: 950px){
        #mlogo{
    	    display:block; max-width:150px; margin-left:0px; margin-bottom:50px; margin-top:30px;
    	}
        #sbox22{
    	    padding-top:40px; padding-left:45px; padding-right:35px;
    	}
    	#fbox{
    	    display:none;
    	}
        #headerab{
    	    font-size:35px;;
    	}
    	#btn11xx{
    		margin:0px auto; float:none; width:100%;
    	}
    	#btn22xx{
    		margin:20px auto; float:none; width:100%;
    	}
        #lastone2{
            padding-left:20px;
        }
        #lastone3{
            padding-left:20px;
        }
        #faqbtn{
         padding-left:0px;
        }
        #faqquestion{
            font-size:17px;
            float:left;
        }
        #faqreal{
            width:95%;
            float:left;
            
        }
        #testiwidth{
            width:500px;
        }
        
        #aftertesti{ 
            padding-top:100px;
        }
        .arrowtesti111{
            display:none;
        }
        #arrowtesti1x{
            cursor:pointer; float:left; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:0px; height: 50px; width:50px;
            font-size:30px; color:white;                                        
        }
        #arrowtesti2x{
            cursor:pointer; margin-left:100px; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:0px; height: 50px; width:50px;
            font-size:30px; color:white;
        }
        #testiarrobox{
            text-align:center;
           display:block;
           max-width:150px;
           float:none; 
           margin:0px auto;
        }
        #testimonialhead{
          font-size:30px;
        }
        #arrowtesti1{
            float:none;                                        
        }
        #arrowtesti2{
            float:none; 
        }
      #thirdblockimg1{
        display:block;
      }
      #thirdblockmargin{
        margin-top:0px;
    }
      #thirdblockimg2{
        display:none;
      }
    
    #massiv{
          font-size:40px;
      }
      #semiblovk{
          margin-top:80px;
      }
      #whatwe{
        margin-top:0px;
        }
      #stata{
        margin-right:0px;
        display:block;
        text-align:left;
        margin-left:25px;
        font-size:12px;
     }
     #stata img{
        margin-right:10px;
     }
      .btnhoo{
        width:100%;
      }
      #joo{
       width:100%; 
       float:none; 
       padding:20px;
       margin-left:0px;
       clear;both;
       display:block;
      }
     
      #joo2{
        display:block;
        margin:30px auto;
        width:100%; 
        float:none;
        padding:20px;
      }
      
      #semiblockhead{
        margin-left:0px;
      }
     #semiblockhead2{
        margin-left:0px;
    }
    
    #semiblockheadbtn{
        margin-left:0px;
        width:100%;
    }
    #semiblockheadmargin{
        margin-top:0px;
    }
      #footlin{
       float:none; margin:0px auto;
       
      } 
      #footlin2{
       float:none; margin:0px auto;
       
      } 
      #footbox2{
        float:none; width:100%;
      }
      #footbox3{
        float:none; width:100%;
     }
      
    }
    
    
    @media screen and (max-width: 960px){
     
      #footlin{
       display:block;
       clear:both;
      } 
      #footlin li{
       text-align:left;
       margin-left:30px;
      } 
      #footlin h4{
       padding-top:60px;
       text-align:left;
       margin-left:30px;
      } 
      
      #footlin2{
       display:block;
       clear:both;
      } 
      #footlin2 li{
       text-align:left;
       margin-left:30px;
      } 
      #footlin2 h4{
       padding-top:60px;
       text-align:left;
       margin-left:30px;
      } 
      
    }
    
    
     @media screen and (max-width: 454px) {
      #massiv{
          font-size:30px;
      }
      #lead2{
          font-size:15px;
      }
       .intro .btn {
           padding-top:10px;
           padding-bottom:10px;
           padding-left:8px;
           padding-right:8px;
       }
    }
    
    
    @media screen and (max-width: 1150px) {
      #stata{
        margin-right:30px;
        font-size:20px;
    }
    
    @media screen and (max-width: 820px) {
      #stata{
        margin-right:10px;
        font-size:20px;
    }
    
    }
    
    @media screen and (max-width: 750px) {
      #visionb{
    	    border:none; margin-top:40px;
    	}
    	#pyly{
        margin-bottom:0px; padding-bottom:0px; margin-top:0px; padding-bottom:0px !important; padding-top:0px !important;
    }
    
    #stata{
        margin-right:0px;
        font-size:20px;
        display:block;
        margin-top:20px;
    }
    
    }
    
    </style>

<!-- Begin Menu Navigation
================================================== -->

<!-- End Menu Navigation
================================================== -->
	<!-- Home Jumbotron
    ================================================== -->
	
	<!-- Container
    ================================================== -->
    
	
	
	<section style="padding-bottom:0px; margin-bottom:0px; width:100%; height:100%; " class="featured-posts">
    		
    				    	<div style="padding-bottom:0px; padding-top:0px;">  
    						
    						
    						<div class="row" style="">
    						    <div class="col-lg-6" id='fbox' style="background-color:#061f2f; height:100%; text-align:left; padding:0px;">
    						        <img  style="max-width:250px; margin-left:50px; margin-top:70px;" src="promptearnlogoo.png" alt="PromptEarn"> 
        						    
        						    <img  style="margin-top:70px; width:100%;" src="image4344.png" alt="PromptEarn"> 
        						    
    									<p style="font-size:22px; max-width:350px; color:white; font-weight:bold; font-family: raleway; 
    									padding-bottom:100px; margin-left:50px;  margin-top:50px; ">
    									    It only takes a few seconds to log into your account.</p>
    							</div>
    							
    							<div class="col-lg-6 col-12" id="sbox22">
        						    	<form action="forgot.php" method="POST">
        						    	    
        						    	    <img  id="mlogo" src="logo/prompt.png" alt="PromptEarn">
        						    	    
                        					<h4 style="padding-left:10px; font-family:raleway;"><b>Forgot Password</b></h4><br>
                        					<p style="padding-left:10px; font-family:raleway;">We’ve got you covered on how to reset your password</p><br>
                        					                        					
                        					<div style="padding:10px;" class="form-group row">
                        						<div style="" class="col-md-12">
                        						    <label style="padding-left:10px; font-family:raleway; font-weight:bold;">Email Address</label>
                        							<input class="form-control" type="email" name="email" placeholder="Type Your Email Address Here">
                        						</div>
                        					</div>
                        					
                        					<input style="margin-left:10px; width:95%; 
                        					text-transform: capitalize; font-family:raleway; background-color:#5dad00;  color:white;" class="btn btn-success" 
                        					type="submit" name="submit" value="Reset Password">
                        					
                        				
                        				</form>
    							</div>
								
    						</div>
								
                            </div>
                            
                          
    			
			</section>
			
			
			
			
    
  	
	
	
	
	
	
			

	<!-- End Footer
    ================================================== -->

</div>

<!-- JavaScript
================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
<script src="assets/js/masonry.pkgd.min.js"></script>
<script src="assets/js/theme.js"></script>

  
</body>
</html>