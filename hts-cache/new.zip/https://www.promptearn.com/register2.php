
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="logo/prompt.png">
<title>Create New Account | The Best Platform for Earning Online With Digital Product</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">
<link href="assets/css/theme.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />
 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;700&display=swap">
  
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  
<!-- Google tag (gtag.js) --> 

<script src="https://js.paystack.co/v1/inline.js"></script>


<script async src="https://www.googletagmanager.com/gtag/js?id=G-30Z5L83XBH"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-30Z5L83XBH');
</script>
</head>
<body class="layout-default">
    
    <style>
    
   
    #pyly{
        margin-bottom:0px; padding-bottom:0px; margin-top:0px;
    }
    @import url(//fonts.googleapis.com/css?family=Montserrat:300,400,500);
.service-11 {
  font-family: "Montserrat", sans-serif;
	color: #8d97ad;
  font-weight: 300;
}

.service-11 h1, .service-11 h2, .service-11 h3, .service-11 h4, .service-11 h5, .service-11 h6 {
  color: #3e4555;
}

.service-11 .font-weight-medium {
	font-weight: 500;
}

.service-11 .bg-light {
    background-color: #f4f8fa !important;
}

.service-11 .subtitle {
    color: #8d97ad;
    line-height: 24px;
}

.service-11 .card.card-shadow {
    -webkit-box-shadow: 0px 0px 30px rgba(115, 128, 157, 0.1);
    box-shadow: 0px 0px 30px rgba(115, 128, 157, 0.1);
}

.service-11 .wrap-service11-box {
  margin-top: 0px;
}

.service-11 .wrap-service11-box .icon-space {
  margin: -120px 0 20px;
}

.service-11 .wrap-service11-box .icon-space .icon-round {
  font-size: 45px;
  color: #ffffff;
}

.service-11 .bg-success-gradiant {
    background: #2cdd9b;
    background: -webkit-linear-gradient(legacy-direction(to right), #2cdd9b 0%, #1dc8cc 100%);
    background: -webkit-gradient(linear, left top, right top, from(#2cdd9b), to(#1dc8cc));
    background: -webkit-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: -o-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: linear-gradient(to right, #2cdd9b 0%, #1dc8cc 100%);
}

.service-11 .icon-round {
		width: 80px;
    line-height: 80px;
}

.service-11 .btn-success-gradiant {
		background: #2cdd9b;
    background: -webkit-linear-gradient(legacy-direction(to right), #2cdd9b 0%, #1dc8cc 100%);
    background: -webkit-gradient(linear, left top, right top, from(#2cdd9b), to(#1dc8cc));
    background: -webkit-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: -o-linear-gradient(left, #2cdd9b 0%, #1dc8cc 100%);
    background: linear-gradient(to right, #2cdd9b 0%, #1dc8cc 100%);
}

.service-11 .btn-success-gradiant:hover {
		background: #1dc8cc;
    background: -webkit-linear-gradient(legacy-direction(to right), #1dc8cc 0%, #2cdd9b 100%);
    background: -webkit-gradient(linear, left top, right top, from(#1dc8cc), to(#2cdd9b));
    background: -webkit-linear-gradient(left, #1dc8cc 0%, #2cdd9b 100%);
    background: -o-linear-gradient(left, #1dc8cc 0%, #2cdd9b 100%);
    background: linear-gradient(to right, #1dc8cc 0%, #2cdd9b 100%);	
}

.service-11 .btn-md {
    padding: 15px 45px;
    font-size: 16px;
}
    #whatwe{
        margin-top:600px;
    }
    #joo{
        max-width:600px; 
        float:left; 
        margin-left:120px;
    }
    .btnhoo{
        background-color:#5dad00;  color:white; width:200px;
    }
    #massiv{
        font-weight:bold; font-size:60px; color:black; font-family:raleway;
    }

    #stata{
        margin-right:40px;
    }
    #footlin{
       float:left; margin-right:90px; 
    } 
    #footlin2{
       float:left; margin-right:0px; 
    }
    #footbox2{
        float:left; width:800px;
    } 
    #footbox3{
        float:right; max-width:750px;
    }
    #joo2{
        max-width:500px; float:left;
    }
    #semiblockhead{
        font-size:35px; font-family: raleway; font-weight:bold; color:#082515;
									line-height:50px; margin-top:30px; margin-left:50px;
    }
    #semiblockhead2{
        font-family: raleway; margin-top:30px; margin-left:50px;
    }
    #semiblockheadbtn{
        margin-left:50px; background-color:#5dad00;  color:white; width:200px;
    }
    #semiblockheadmargin{
        margin-top:200px;
    }
    
    #thirdblockimg1{
        display:none;
    }
    #thirdblockmargin{
        margin-top:200px;
    }
    #testimonialhead{
       text-align:center; max-width:700px; font-size:35px; font-family: raleway; font-weight:bold; color:black;
	   line-height:50px; margin:0px auto; float:none; 
    }
    #arrowtesti1{
        cursor:pointer; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:13px; float:right; height: 50px; width:50px;
        font-size:30px; color:white;                                        
    }
    #arrowtesti2{
        cursor:pointer; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:13px; float:right; height: 50px; width:50px;
        font-size:30px; color:white;
    }
    #testiarrobox{
       display:none;
    }
    #aftertesti{ 
        padding-bottom:0px; padding-top:200px; margin-bottom:0px; width:100%;
    }
    #faqquestion{
        font-family:raleway; font-weight:bold;
    }
    #faqbtn{
        background-color:white; text-align:left; white-space:normal; width:100%; box-shadow:none; color:black; text-decoration:none;
    }
    #lastone2{
        padding-top:60px; padding-left:60px;
    }
    #lastone3{
        padding-left:60px;
    }
    #btn11xx{
		margin-left:0px; float:left; background-color:#5dad00;  color:white; width:220px;
	}
	#btn22xx{
		padding-left:20px; float:left; margin-left:20px;  padding-right:20px; width:220px; background-color:transparent; border:1px solid #112111; color:#112111;
	}
	#headerab{
	    font-size:65px; font-family: raleway; font-weight:bold; color:black; text-align:center;
	}
	#visionb{
	    border-left:3px solid #5dad00; text-align:center;
	}
	#sbox22{
	    padding-top:110px; padding-left:90px; padding-right:90px;
	}
	#mlogo{
	    display:none;
	}
	
    @media screen and (max-width: 950px){
        #mlogo{
    	    display:block; max-width:150px; margin-left:0px; margin-bottom:50px; margin-top:30px;
    	}
        #sbox22{
    	    padding-top:40px; padding-left:45px; padding-right:35px;
    	}
    	#fbox{
    	    display:none;
    	}
        #headerab{
    	    font-size:35px;;
    	}
    	#btn11xx{
    		margin:0px auto; float:none; width:100%;
    	}
    	#btn22xx{
    		margin:20px auto; float:none; width:100%;
    	}
        #lastone2{
            padding-left:20px;
        }
        #lastone3{
            padding-left:20px;
        }
        #faqbtn{
         padding-left:0px;
        }
        #faqquestion{
            font-size:17px;
            float:left;
        }
        #faqreal{
            width:95%;
            float:left;
            
        }
        #testiwidth{
            width:500px;
        }
        
        #aftertesti{ 
            padding-top:100px;
        }
        .arrowtesti111{
            display:none;
        }
        #arrowtesti1x{
            cursor:pointer; float:left; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:0px; height: 50px; width:50px;
            font-size:30px; color:white;                                        
        }
        #arrowtesti2x{
            cursor:pointer; margin-left:100px; background-color:#424d42; color:white; margin-right:30px; border-radius:100%; padding-top:6px;  padding-left:0px; height: 50px; width:50px;
            font-size:30px; color:white;
        }
        #testiarrobox{
            text-align:center;
           display:block;
           max-width:150px;
           float:none; 
           margin:0px auto;
        }
        #testimonialhead{
          font-size:30px;
        }
        #arrowtesti1{
            float:none;                                        
        }
        #arrowtesti2{
            float:none; 
        }
      #thirdblockimg1{
        display:block;
      }
      #thirdblockmargin{
        margin-top:0px;
    }
      #thirdblockimg2{
        display:none;
      }
    
    #massiv{
          font-size:40px;
      }
      #semiblovk{
          margin-top:80px;
      }
      #whatwe{
        margin-top:0px;
        }
      #stata{
        margin-right:0px;
        display:block;
        text-align:left;
        margin-left:25px;
        font-size:12px;
     }
     #stata img{
        margin-right:10px;
     }
      .btnhoo{
        width:100%;
      }
      #joo{
       width:100%; 
       float:none; 
       padding:20px;
       margin-left:0px;
       clear;both;
       display:block;
      }
     
      #joo2{
        display:block;
        margin:30px auto;
        width:100%; 
        float:none;
        padding:20px;
      }
      
      #semiblockhead{
        margin-left:0px;
      }
     #semiblockhead2{
        margin-left:0px;
    }
    
    #semiblockheadbtn{
        margin-left:0px;
        width:100%;
    }
    #semiblockheadmargin{
        margin-top:0px;
    }
      #footlin{
       float:none; margin:0px auto;
       
      } 
      #footlin2{
       float:none; margin:0px auto;
       
      } 
      #footbox2{
        float:none; width:100%;
      }
      #footbox3{
        float:none; width:100%;
     }
      
    }
    
    
    @media screen and (max-width: 960px){
     
      #footlin{
       display:block;
       clear:both;
      } 
      #footlin li{
       text-align:left;
       margin-left:30px;
      } 
      #footlin h4{
       padding-top:60px;
       text-align:left;
       margin-left:30px;
      } 
      
      #footlin2{
       display:block;
       clear:both;
      } 
      #footlin2 li{
       text-align:left;
       margin-left:30px;
      } 
      #footlin2 h4{
       padding-top:60px;
       text-align:left;
       margin-left:30px;
      } 
      
    }
    
    
     @media screen and (max-width: 454px) {
      #massiv{
          font-size:30px;
      }
      #lead2{
          font-size:15px;
      }
       .intro .btn {
           padding-top:10px;
           padding-bottom:10px;
           padding-left:8px;
           padding-right:8px;
       }
    }
    
    
    @media screen and (max-width: 1150px) {
      #stata{
        margin-right:30px;
        font-size:20px;
    }
    
    @media screen and (max-width: 820px) {
      #stata{
        margin-right:10px;
        font-size:20px;
    }
    
    }
    
    @media screen and (max-width: 750px) {
      #visionb{
    	    border:none; margin-top:40px;
    	}
    	#pyly{
        margin-bottom:0px; padding-bottom:0px; margin-top:0px; padding-bottom:0px !important; padding-top:0px !important;
    }
    
    #stata{
        margin-right:0px;
        font-size:20px;
        display:block;
        margin-top:20px;
    }
    
    }
    
    </style>

<!-- Begin Menu Navigation
================================================== -->

<!-- End Menu Navigation
================================================== -->
	<!-- Home Jumbotron
    ================================================== -->
	
	<!-- Container
    ================================================== -->
    
	
	
	<section style="padding-bottom:0px; margin-bottom:0px; width:100%; height:100%; " class="featured-posts">
    		
    				    	<div style="padding-bottom:0px; padding-top:0px;">  
    						
    						
    						<div class="row" style="">
    						    <div class="col-lg-6" id='fbox' style="background-color:#061f2f; height:100%; text-align:left; padding:0px;">
    						        <img  style="max-width:250px; margin-left:50px; margin-top:70px;" src="promptearnlogoo.png" alt="PromptEarn"> 
        						    
        						    <img  style="margin-top:70px; width:100%;" src="image4344.png" alt="PromptEarn"> 
        						    
    									<p style="font-size:22px; max-width:350px; color:white; font-weight:bold; font-family: raleway; 
    									padding-bottom:100px; margin-left:50px;  margin-top:50px; ">
    									    It only takes a few seconds to create your account.</p>
    							</div>
    							
    							<div class="col-lg-6 col-12" id="sbox22">
        						    	    
        						    	    <img  id="mlogo" src="logo/prompt.png" alt="PromptEarn">
        						    	    
                        					<h4 style="padding-left:10px; font-family:raleway;"><b>Create New Account</b></h4><br>
                        					<p style="padding-left:10px; font-family:raleway;">Sign up with us and enjoy the best experience</p>
                        				
                        				
                        									<div style="display:none;" id="error23" class='alert alert-danger'>Please fill all fields in the form</div>
					<div style="padding:10px; margin-bottom:0px; padding-bottom:0px" class="form-group row">
						<div class="col-md-12">
						    <label style="font-family:raleway; font-weight:bold;">Full Name</label>
							<input class="form-control" type="text" id="name" placeholder="Type Name Here">
						</div>
					</div>
					<div style="padding:10px;  margin-bottom:0px; padding-bottom:0px" class="form-group row">
						<div class="col-md-12">
						    <label style="font-family:raleway; font-weight:bold;">Email Address</label>
							<input class="form-control" type="email" id="email" placeholder="Type Email Here">
						</div>
					</div>
					<div style="padding:10px;  margin-bottom:0px; padding-bottom:0px" class="form-group row">
					    <div class="col-md-12">
					        <label style="font-family:raleway; font-weight:bold;">Country</label>
					        <select class="form-control" id="country" name="country">
													
														<option style="color:black" value="">Select Country</option>
														<option style="color:black">Afghanistan	</option>	
														<option style="color:black">Albania	</option>
														<option style="color:black">Algeria	</option>	
														<option style="color:black">American Samoa	</option>	
														<option style="color:black">Andorra	</option>
														<option style="color:black">Angola	</option>
														<option style="color:black">Anguilla	</option>
														<option style="color:black">Antarctica	</option>	
														<option style="color:black">Antigua and Barbuda</option>
														<option style="color:black">Argentina	</option>	
														<option style="color:black">Armenia	</option>	
														<option style="color:black">Aruba	</option>
														<option style="color:black">Australia	</option>
														<option style="color:black">Austria	</option>	
														<option style="color:black">Azerbaijan	</option>
														<option style="color:black">Bahamas	</option>
														<option style="color:black">Bahrain</option>	
														<option style="color:black">Bangladesh </option>
														<option style="color:black">Barbados </option>
														<option style="color:black">Belarus </option>
														<option style="color:black">Belgium	</option>
														<option style="color:black">Belize	</option>
														<option style="color:black">Benin	</option>
														<option style="color:black">Bermuda	</option>
														<option style="color:black">Bhutan	</option>
														<option style="color:black">Bolivia	</option>
														<option style="color:black">Bosnia and Herzegovina	</option>
														<option style="color:black">Botswana	</option>
														<option style="color:black">Brazil	</option>
														<option style="color:black">British Indian Ocean Territory	</option>
														<option style="color:black">British Virgin Islands	</option>
														<option style="color:black">Brunei	</option>
														<option style="color:black">Bulgaria	</option>
														<option style="color:black">Burkina Faso	</option>
														<option style="color:black">Burundi</option>
														<option style="color:black">Cambodia	</option>	
														<option style="color:black">Cameroon	</option>
														<option style="color:black">Canada	</option>
														<option style="color:black">Cape Verde	</option>
														<option style="color:black">Cayman Islands	</option>
														<option style="color:black">Central African Republic	</option>
														<option style="color:black">Chad	</option>
														<option style="color:black">Chile	</option>
														<option style="color:black">China	</option>
														<option style="color:black">Christmas Island	</option>
														<option style="color:black">Cocos Islands	</option>
														<option style="color:black">Colombia	</option>
														<option style="color:black">Comoros	</option>
														<option style="color:black">Cook Islands	</option>
														<option style="color:black">Costa Rica	</option>	
														<option style="color:black">Croatia	</option>	
														<option style="color:black">Cuba	</option>
														<option style="color:black">Curacao	</option>
														<option style="color:black">Cyprus	</option>
														<option style="color:black">Czech Republic	</option>
														<option style="color:black">Democratic Republic of the Congo	</option>
														<option style="color:black">Denmark	</option>
														<option style="color:black">Djibouti	</option>
														<option style="color:black">Dominica	</option>
														<option style="color:black">Dominican Republic	</option>
														<option style="color:black">East Timor	</option>
														<option style="color:black">Ecuador	</option>
														<option style="color:black">Egypt	</option>
														<option style="color:black">El Salvador	</option>
														<option style="color:black">Equatorial Guinea	</option>
														<option style="color:black">Eritrea	</option>
														<option style="color:black">Estonia	</option>
														<option style="color:black">Ethiopia	</option>
														<option style="color:black">Falkland Islands	</option>
														<option style="color:black">Faroe Islands	</option>
														<option style="color:black">Fiji	</option>
														<option style="color:black">Finland	</option>
														<option style="color:black">France	</option>
														<option style="color:black">French Polynesia	</option>
														<option style="color:black">Gabon	</option>
														<option style="color:black">Gambia	</option>
														<option style="color:black">Georgia	</option>
														<option style="color:black">Germany	</option>
														<option style="color:black">Ghana	</option>
														<option style="color:black">Gibraltar	</option>
														<option style="color:black">Greece	</option>
														<option style="color:black">Greenland	</option>
														<option style="color:black">Grenada	</option>
														<option style="color:black">Guam	</option>
														<option style="color:black">Guatemala	</option>
														<option style="color:black">Guernsey	</option>
														<option style="color:black">Guinea</option>
														<option style="color:black">Guinea-Bissau	</option>
														<option style="color:black">Guyana	</option>
														<option style="color:black">Haiti	</option>
														<option style="color:black">Honduras	</option>
														<option style="color:black">Hong Kong	</option>
														<option style="color:black">Hungary</option>
														<option style="color:black">Iceland	</option>
														<option style="color:black">India	</option>	
														<option style="color:black">Indonesia	</option>
														<option style="color:black">Iran	</option>	
														<option style="color:black">Iraq	</option>
														<option style="color:black">Ireland	</option>
														<option style="color:black">Isle of Man	</option>
														<option style="color:black">Israel	</option>
														<option style="color:black">Italy	</option>
														<option style="color:black">Ivory Coast	</option>
														<option style="color:black">Jamaica	</option>	
														<option style="color:black">Japan	</option>
														<option style="color:black">Jersey	</option>
														<option style="color:black">Jordan	</option>
														<option style="color:black">Kazakhstan	</option>
														<option style="color:black">Kenya	</option>
														<option style="color:black">Kiribati	</option>
														<option style="color:black">Kosovo</option>
														<option style="color:black">Kuwait	</option>
														<option style="color:black">Kyrgyzstan	</option>
														<option style="color:black">Laos	</option>
														<option style="color:black">Latvia	</option>
														<option style="color:black">Lebanon	</option>
														<option style="color:black">Lesotho	</option>
														<option style="color:black">Liberia	</option>
														<option style="color:black">Libya	</option>
														<option style="color:black">Liechtenstein	</option>
														<option style="color:black">Lithuania	</option>
														<option style="color:black">Luxembourg	</option>
														<option style="color:black">Macau	</option>
														<option style="color:black">Macedonia	</option>
														<option style="color:black">Madagascar	</option>
														<option style="color:black">Malawi	</option>
														<option style="color:black">Malaysia	</option>	
														<option style="color:black">Maldives	</option>	
														<option style="color:black">Mali	</option>
														<option style="color:black">Malta	</option>
														<option style="color:black">Marshall Islands	</option>
														<option style="color:black">Mauritania	</option>
														<option style="color:black">Mauritius	</option>
														<option style="color:black">Mayotte	</option>
														<option style="color:black">Mexico	</option>
														<option style="color:black">Micronesia	</option>
														<option style="color:black">Moldova	</option>
														<option style="color:black">Monaco	</option>
														<option style="color:black">Mongolia	</option>
														<option style="color:black">Montenegro	</option>
														<option style="color:black">Montserrat	</option>
														<option style="color:black">Morocco	</option>
														<option style="color:black">Mozambique	</option>
														<option style="color:black">Myanmar	</option>
														<option style="color:black">Namibia	</option>
														<option style="color:black">Nauru	</option>
														<option style="color:black">Nepal	</option>
														<option style="color:black">Netherlands	</option>
														<option style="color:black">Netherlands Antilles	</option>
														<option style="color:black">New Caledonia	</option>
														<option style="color:black">New Zealand	</option>	
														<option style="color:black">Nicaragua	</option>
														<option style="color:black">Niger	</option>
														<option style="color:black">Nigeria	</option>
														<option style="color:black">Niue	</option>	
														<option style="color:black">North Korea	</option>
														<option style="color:black">Northern Mariana Islands	</option>
														<option style="color:black">Norway	</option>
														<option style="color:black">Oman	</option>
														<option style="color:black">Pakistan	</option>
														<option style="color:black">Palau	</option>
														<option style="color:black">Palestine	</option>
														<option style="color:black">Panama	</option>
														<option style="color:black">Papua New Guinea	</option>
														<option style="color:black">Paraguay	</option>	
														<option style="color:black">Peru	</option>	
														<option style="color:black">Philippines	</option>
														<option style="color:black">Pitcairn	</option>	
														<option style="color:black">Poland	</option>	
														<option style="color:black">Portugal	</option>
														<option style="color:black">Puerto Rico	</option>
														<option style="color:black">Qatar	</option>
														<option style="color:black">Republic of the Congo	</option>
														<option style="color:black">Reunion	</option>
														<option style="color:black">Romania	</option>
														<option style="color:black">Russia	</option>	
														<option style="color:black">Rwanda	</option>
														<option style="color:black">Saint Barthelemy	</option>
														<option style="color:black">Saint Helena	</option>
														<option style="color:black">Saint Kitts and Nevis	</option>
														<option style="color:black">Saint Lucia	</option>
														<option style="color:black">Saint Martin	</option>
														<option style="color:black">Saint Pierre and Miquelon	</option>
														<option style="color:black">Saint Vincent and the Grenadines	</option>
														<option style="color:black">Samoa	</option>
														<option style="color:black">San Marino	</option>	
														<option style="color:black">Sao Tome and Principe	</option>
														<option style="color:black">Saudi Arabia	</option>
														<option style="color:black">Senegal	</option>
														<option style="color:black">Serbia	</option>
														<option style="color:black">Seychelles	</option>
														<option style="color:black">Sierra Leone	</option>
														<option style="color:black">Singapore	</option>
														<option style="color:black">Sint Maarten	</option>
														<option style="color:black">Slovakia	</option>
														<option style="color:black">Slovenia	</option>
														<option style="color:black">Solomon Islands	</option>
														<option style="color:black">Somalia</option>
														<option style="color:black">South Africa	</option>
														<option style="color:black">South Korea	</option>
														<option style="color:black">South Sudan	</option>
														<option style="color:black">Spain	</option>
														<option style="color:black">Sri Lanka	</option>
														<option style="color:black">Sudan	</option>
														<option style="color:black">Suriname	</option>
														<option style="color:black">Svalbard and Jan Mayen	</option>
														<option style="color:black">Swaziland	</option>	
														<option style="color:black">Sweden	</option>	
														<option style="color:black">Switzerland	</option>
														<option style="color:black">Syria	</option>
														<option style="color:black">Taiwan	</option>	
														<option style="color:black">Tajikistan	</option>
														<option style="color:black">Tanzania	</option>
														<option style="color:black">Thailand	</option>
														<option style="color:black">Togo	</option>	
														<option style="color:black">Tokelau	</option>
														<option style="color:black">Tonga	</option>
														<option style="color:black">Trinidad and Tobago	</option>
														<option style="color:black">Tunisia	</option>	
														<option style="color:black">Turkey	</option>
														<option style="color:black">Turkmenistan	</option>
														<option style="color:black">Turks and Caicos Islands	</option>
														<option style="color:black">Tuvalu	</option>
														<option style="color:black">U.S. Virgin Islands	</option>
														<option style="color:black">Uganda	</option>
														<option style="color:black">Ukraine	</option>
														<option style="color:black">United Arab Emirates	</option>
														<option style="color:black">United Kingdom</option>
														<option style="color:black">United States</option>
														<option style="color:black">Uruguay	</option>	
														<option style="color:black">Uzbekistan	</option>
														<option style="color:black">Vanuatu	</option>
														<option style="color:black">Vatican	</option>
														<option style="color:black">Venezuela	</option>
														<option style="color:black">Vietnam	</option>
														<option style="color:black">Wallis and Futuna	</option>
														<option style="color:black">Western Sahara	</option>
														<option style="color:black">Yemen	</option>
														<option style="color:black">Zambia	</option>
														<option style="color:black">Zimbabwe	</option>
																	
													</select>
					    </div>
					</div>
					<div style="padding:10px;  margin-bottom:0px; padding-bottom:0px" class="form-group row">
						<div class="col-md-12">
						    <label style="font-family:raleway; font-weight:bold;">Password</label>
							<input class="form-control" type="password" id="password" placeholder="Type Password Here ">
						</div>
					</div>
					
					<div style="padding:10px;  margin-bottom:0px; padding-bottom:0px" class="form-group row">
					    <div class="col-md-12">
					        <label style="font-family:raleway; font-weight:bold;">How would you like to pay?</label>
					        <select class="form-control" id="paym" name="paym">
									<option style="color:black" value="Squad">Squad (Naira)</option>
									<option style="color:black; display:none;" value="Paystack">Paystack (Naira)</option>
									<option id="flutter22" style="color:black" value="Flutterwave">Flutterwave (Momo)</option>
									<option style="display:none; color:black" value="Stripe">Stripe (USD)</option>
							</select>
						</div>
					</div>
					
					<div style="padding:10px;  margin-bottom:0px; padding-bottom:0px" class="tacbox">
                      <input onchange="activateButton(this)" class="inputff" id="checkbox" type="checkbox" />
                      <label id="checklab" style="font-size:13px; padding-bottom:10px;" for="checkbox"> I agree to these <a href="tac.html">Terms and Conditions</a>.</label>
                    </div>
                    
					<button style="margin-left:10px; width:95%; text-transform: capitalize; font-family:raleway; background-color:#5dad00;  color:white;" 
					class="btn btn-success" disabled id="submit" onclick="paynoww()" name="Proceed to Payment">Create Account</button>
					
					
					<br><br><p style="padding-left:10px; text-align:center; font-family:raleway; ">Already have an account? <a href="login.php">Login here</a></p>
                        					
                        				
                        				
    							</div>
								
    						</div>
								
                            </div>
                            
                          
    			
			</section>
			
			
			
			 <script src="https://checkout.squadco.com/widget/squad.min.js"></script> 

                       


					<script>
					
					
				
					
					 function paynoww(){
					      var paym = $("#paym").val()
					      
					      if(paym == 'Squad'){
					         SquadPay()
					      }else if(paym == 'Paystack'){
					         payWithPaystack()
					      }else if(paym == 'Flutterwave'){
					         makePayment()
					      }else{
					          stripepay();
					      }
					  }
					    
					    
					    
					  function makeid(length){
							let result = '';
							const characters = '0123456789';
							const charactersLength = characters.length;
							let counter = 0;
							while (counter < length) {
							  result += characters.charAt(Math.floor(Math.random() * charactersLength));
							  counter += 1;
							}
							return result;
						}




					    function SquadPay() {
					        
					                          var ema = $("#email").val();
                    					      var nam = $("#name").val();
                    					      var pho = $("#password").val();
                    					      var country = $("#country").val();
                    					      var reffe = "4"+makeid(15)+"5"
                    				          
                    				         
                    				          if(ema == '' || nam == '' || pho == '' || country == ''){
                    					          $("#error23").show();
                    					      }else{
                    					            $.ajax({
                    									type: "POST",
                    									url: "regopay2.php",
                    									data: {"country": country, "reference": ""+reffe, "email": ema, "name": nam, "password": pho, "from":"2"},
                    									success: function(html){
                    											if(html == 'done'){
                    											    
                    											     const squadInstance = new squad({
                                                                        onClose: () => console.log("Widget closed"),
                                                                        onLoad: () => console.log(`Linked successfully`),
                                                                        onSuccess: () => verifyTransactionOnBackend3(reffe),
                                                                        key: "pk_7cf0356aeeb33d69db039c3cf9f91b3e28c098c7",
                                                                        //Change key (test_pk_sample-public-key-1) to the key on your Squad Dashboard
                                                                        email: ema,
                                                                        transaction_ref: reffe,
                                                                        amount: 500000,
                                                                        //Enter amount in Naira or Dollar (Base value Kobo/cent already multiplied by 100)
                                                                        currency_code: "NGN"
                                                                      });
                                                                      squadInstance.setup();
                                                                      squadInstance.open();
                                              
                    											}else{
                    												alert(html);
                    											}
                    									} 
                    								});
                    								
                    					      }
                          
										
									} 
							

					  function verifyTransactionOnBackend3(reff) {
					      
					                                  

					      var ema = $("#email").val();
					      var nam = $("#name").val();
					      var pho = $("#password").val();
					      var sourcee = "other";
					      
								setTimeout(function(){
										window.location.replace('regopaysquad.php?sourcee='+sourcee+'&country='+country+'&password='+pho+'&ref='+reff+'&name='+nam+'&email='+ema+'&van='+reff);
								},10000)
					  }
					  
					  


					  function makePayment() {
					      var ema = $("#email").val();
					      var nam = $("#name").val();
					      var pho = $("#password").val();
					      var country = $("#country").val();
					      
					       var reffe = "4"+makeid(15)+"5"
					        
					        if(country == 'Ghana'){
    					          var pricc = 14 * 5;
    					          var curr = "GHS";
    					      }else if(country == 'Nigeria'){
    					          var pricc = 5000;
    					          var curr = "NGN";
    					      }else if(country == 'United States'){
    					          var pricc = 5;
    					          var curr = "USD";
    					      }else{
    					          var pricc = 390 * 5;
    					          var curr = "XAF";
    					      }
					      
					            $.ajax({
									type: "POST",
									url: "regopay2.php",
									data: {"country": country, "reference": ""+reffe, "email": ema, "name": nam, "password": pho, "from":"2"},
									success: function(html){
											if(html == 'done'){
												FlutterwaveCheckout({
                        						  public_key: "FLWPUBK-3deb34e22c7f1c58ba271ab83bf0b4dc-X",
                        						  tx_ref: reffe,
                        						  amount: pricc,
                        						  currency: ""+curr,
                        						  payment_options: "card, mobilemoneyghana, ussd",
                        						  callback: function(payment) {
                        							verifyTransactionOnBackend(payment.transaction_id, reffe);
                        						  },
                        						  onclose: function(incomplete) {
                        							if (incomplete || window.verified === false) {
                        							  document.querySelector("#payment-failed").style.display = 'block';
                        							} else {
                        							  document.querySelector("form").style.display = 'none';
                        							  if (window.verified == true) {
                        								document.querySelector("#payment-success").style.display = 'block';
                        							  } else {
                        								document.querySelector("#payment-pending").style.display = 'block';
                        							  }
                        							}
                        						  },
                        						  meta: {
                        							consumer_id: 23,
                        							consumer_mac: "92a3-912ba-1192a",
                        						  },
                        						  customer: {
                        							email: ema,
                        							phone_number: 0023234353,
                        							name: nam,
                        						  },
                        						  customizations: {
                        							title: "PromptEarn",
                        							description: "PrompEarn Affiliate Activation",
                        							logo: "https://promptearn.com/logo/prompt.png",
                        						  },
                        						});
											}else{
												alert(html);
											}
									}
								});
					  }

					  function verifyTransactionOnBackend(transactionId, reff) {
					      var ema = $("#email").val();
					      var nam = $("#name").val();
					      var pho = $("#password").val();
					      var country = $("#country").val();
					      
					                                   var sourcee = "other";
					      
								setTimeout(function(){
										window.location.replace('regopay.php?sourcee='+sourcee+'&country='+country+'&password='+pho+'&ref='+reff+'&name='+nam+'&email='+ema+'&van='+transactionId);
								},10000)
					  }
					  
					  
					  
					  function stripepay() {
					      var ema = $("#email").val();
					      var nam = $("#name").val();
					      var pho = $("#password").val();
					      var country = $("#country").val();
					      
								setTimeout(function(){
										window.location.replace('paynow/paystripereg2.php?country='+country+'&password='+pho+'&name='+nam+'&email='+ema);
								},100)
					  }
					  
					  
					               function payWithPaystack(e) {
                                      var ema = $("#email").val();
                    					      var nam = $("#name").val();
                    					      var pho = $("#password").val();
                    					      var country = $("#country").val();
                    					      var reffe = "2"+makeid(15)+"5"
                    				          
                    				         
                    				          if(ema == '' || nam == '' || pho == '' || country == ''){
                    					          $("#error23").show();
                    					      }else{
                    					            $.ajax({
                    									type: "POST",
                    									url: "regopay2.php",
                    									data: {"country": country, "reference": ""+reffe, "email": ema, "name": nam, "password": pho, "from":"2"},
                    									success: function(html){
            											if(html == 'done'){
            												    let handler = PaystackPop.setup({
                                                                key: 'pk_live_823a7aad8ddcda256b4dbb3d3ab2aa0aba4594d8', // Replace with your public key
                                                                email: document.getElementById("email").value,
                                                                amount: 5000 * 100,
                                                                ref: ''+reffe, // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
                                                                // label: "Optional string that replaces customer email"
                                                                onClose: function(){
                                                                  alert('Window closed.');
                                                                },
                                                                callback: function(response){
                                                                  let messag22e = response.reference;
                                                                  
                                                                      var ema = $("#email").val();
                                            					      var nam = $("#name").val();
                                            					      var pho = $("#phone").val();
                                            					                                                                              var sourcee = "other";
                                            					      
                                            					      
                                            								setTimeout(function(){
                                            								    	window.location.replace('regopaypaystack.php?sourcee='+sourcee+'&country='+country+'&password='+pho+'&ref='+reffe+'&name='+nam+'&email='+ema+'&van='+reffe);
                                            								},400)
								
                                                                  
                                                                }
                                                              });
                                                            
                                                              handler.openIframe();
            											}else{
            												alert(html);
            											}
            									}
            								});
            								
                                        }
					               }

                        
                        
                        
                        
                        
                        
                        
					  
					  
					  
					  



					 
					</script>
					
					
			
			
    
  	
	
	
	
	
	
			

	<!-- End Footer
    ================================================== -->

</div>

<!-- JavaScript
================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>
<script src="assets/js/masonry.pkgd.min.js"></script>
<script src="assets/js/theme.js"></script>

  <script src="https://checkout.flutterwave.com/v3.js"></script>

<script>

	$('#country').on('change', function() {
                          var cou = $('#country').val();
                          if(cou == 'Nigeria'){
                             
                              $("#flutter22").hide();
                          }else{
                              $("#flutter22").show();
                          }
                        });
                        
                        
                        
 function disableSubmit() {
  document.getElementById("submit").disabled = true;
 }

  function activateButton(element) {

      if(element.checked) {
        document.getElementById("submit").disabled = false;
       }
       else  {
        document.getElementById("submit").disabled = true;
      }

  }
</script>



</body>
</html>